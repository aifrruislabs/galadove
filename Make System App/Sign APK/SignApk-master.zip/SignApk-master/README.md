# SignApk

SignApk is used to sign the apk file after repack. The easiest way ever.

How to do?

download all files and put the repacked apk in that folder.

open cmd in windows 8.1

write command

java -jar signapk.jar certificate.pem key.pk8 your-app.apk your-app-signed.apk
